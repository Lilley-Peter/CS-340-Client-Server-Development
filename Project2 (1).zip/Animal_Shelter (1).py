from pymongo import MongoClient
from bson.json_util import dumps
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username = None, password = None):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections
        
        #client = MongoClient('localhost', 39488)
        
        if username and password:
            self.client = MongoClient('mongodb://accuser:test1234@localhost:39488/ACC')
        else:                        
            self.client = MongoClient('mongodb://localhost:39488/ACC')
        self.database = self.client['ACC']

    def create(self, data):
        if data is not None:
            self.database.animals.insert_one(data)  # data should be dictionary            
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self,criteria):
        if criteria:
            data = self.database.animals.find(criteria,{"_id": False})
        else:
            data = self.database.animals.find({},{"_id": False})
        return data
    
    def update(self, query, record):
        if record is not None:
            update_result = self.database.animals.update_many(query, record)
            result = "Record Updated: " + json.dumps(update_result.modified_count)
            return result
        else:
            raise Exception("Data not found")
    
    def delete(self, data):
        if data is not None:
            delete_result = self.database.animals.delete_many(data)
            result = "Documents deleted: " + json.dumps(delete_result.deleted_count)
            return result
        else:
            raise Exception("Record does not exist")